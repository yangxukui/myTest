package com.liuwei.testng;

public class Test {
}
