//package com.liuwei.testng.tr;
//
//import static  com.liuwei.testng.common.TestConfigManager.getConfigByKey;
//
//import com.liuwei.testng.common.LogUtil;
//import org.testng.Assert;
//
//import java.lang.reflect.Method;
//import java.util.List;
//
//public class TrClient {
//
//    public static <T,R> R call(String serviceUrlConfigName, Class<?> servicceClass , String methodName, Class<T>requestClass,
//                               List<Object> parameterList){
//        Method method = null;
//        try{
//            method = servicceClass.getMethod(methodName,requestClass);
//        }catch (NoSuchMethodException e){
//            Assert.fail(e.getMessage(), e);
//        }
//        String serviceAddress = getConfigByKey(serviceUrlConfigName);
//        Assert.assertNotNull(serviceAddress, "failed to fetch tr address config");
//        return (R) TrClient.call(serviceAddress, servicceClass, method, parameterList);
//    }
//
//    public static <T> Object call(String serviceUrl, Class<T> servicce, Method method,List<Object> parameterList){
//        LogUtil.info("============ call Tr:"+ servicce.getName());
//
//
//    }
//    public static void printParameterList(List<Object> parameterList){
//        if(parameterList == null){
//            return;
//        }
//        LogUtil.info("Tr request:");
//        for(Object parameter:parameterList){
//            if(parameter != null){
//
//            }
//        }
//    }
//    public static void printPretty(Object object){
//        try{
//            LogUtil.info();
//        }catch (Exception e){
//
//        }
//    }
//}
