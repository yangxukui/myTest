package com.liuwei.testng.testCase;

public class loadBankInfoService {
}
