package com.liuwei.testng.common;

import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;

import java.net.URLEncoder;
import java.util.Map;
import java.util.UUID;


public class RequestService  {
    public static Request getRequest(Map<String,String> map, String requestString, String operationType){
        String uuid = UUID.randomUUID().toString();
        String rpcHostName = TestConfigManager.getTestConfig().getProperty("rpchostname");
        String httpprotocol = TestConfigManager.getTestConfig().getProperty("httpprotocol");
        String env = TestConfigManager.getTestConfig().getProperty("ENV");
        String appId = TestConfigManager.getTestConfig().getProperty("APPID");
        MediaType mediaType = MediaType.parse("application/json;charset=UTF-8");
        RequestBody body = RequestBody.create(mediaType,requestString);
        String tenantId = TestConfigManager.getTestConfig().getProperty("TENANTID");
        String cookie = "ctoken=" + map.get("ctoken")+";"
                +"ALIPAYJSESSIONID=" + map.get("alipayjessionid")+";" +"session.cookieNameId=ALIPAYJSESSIONID;"
                +"userId="+map.get("userId");
        System.out.print("cookie is:"+cookie +"\n");
        Request request = new Request.Builder()
                .url(httpprotocol + rpcHostName + "/mgw.htm")
                .method("POST",body)
                .addHeader("Host",rpcHostName)
                .addHeader("Accept", "*/*")
                .addHeader("appId", appId)
                .addHeader("workspaceId", env)
                .addHeader("version", "2.0")
                .addHeader("clientId", "448155155444411|856562656526565")
                .addHeader("x-cors-" + appId.toLowerCase() + "-" +env, "1")
                .addHeader("Accept-Language", "en-CN")
                .addHeader("OPERATION-TYPE", operationType)
                .addHeader("uuid", uuid)
                .addHeader("did", "W/y4ghfdhFEWh3jgh8tryj")
                .addHeader("tenantId", tenantId)
                .addHeader("ts", "1544009617477")
                .addHeader("User-Agent", "Skywalker/1 CFNetwork/975.0.3 Darwin/18.2.0")
                .addHeader("cache-control", "no-cache")
                .addHeader("Content-Type", "application/x-www-from-urlencoded;charset=UTF-8")
                .addHeader("Cookie", cookie)
                .addHeader("Connection", "keep-alive")
                .build();
        System.out.print("request is:"+request +"\n");
        return request;
    }

    public static Request getRequest(Map<String,String> map, String requestString, String operationType,String contentType){
        String uuid = UUID.randomUUID().toString();
        int id = (int)(Math.random()*1000);
        String requestBody = "id="+id+"&operationType="+operationType+"&requestData="+ URLEncoder.encode(requestString)+"&ts="+System.currentTimeMillis();
        String rpcHostName = TestConfigManager.getTestConfig().getProperty("rpchostname");
        String httpprotocol = TestConfigManager.getTestConfig().getProperty("httpprotocol");
        String env = TestConfigManager.getTestConfig().getProperty("ENV");
        String appId = TestConfigManager.getTestConfig().getProperty("APPID");
        String tenantId = TestConfigManager.getTestConfig().getProperty("TENANTID");

        System.out.print("requestBody is:"+requestBody +"\n");
        MediaType mediaType = MediaType.parse(contentType);
        RequestBody body = RequestBody.create(mediaType,requestString);
        System.out.print("requestBody is:"+body +"\n");
        String cookie = "";
        if(map.get("ctoken")!=null && map.get("alipayjessionid")!=null){
            cookie = "ctoken=" + map.get("ctoken")+";"
                    +"ALIPAYJSESSIONID=" + map.get("alipayjessionid")+";" +"session.cookieNameId=ALIPAYJSESSIONID;"
                    +"userId="+map.get("userId");
        }
        if(map.get("userId")!= null && map.get("userId") !=""){
            cookie += ";userId=" + map.get("userId")+";session.cookieNameId=ALIPAYJSESSIONID;";
        }
        System.out.print("cookie is:"+cookie +"\n");
        Request request = new Request.Builder()
                .url(httpprotocol + rpcHostName + "/mgw.htm")
                .method("POST",body)
                .addHeader("Host",rpcHostName)
                .addHeader("Accept", "*/*")
                .addHeader("appId", appId)
                .addHeader("AppId", appId)
                .addHeader("workspaceId", env)
                .addHeader("version", "2.0")
                .addHeader("did", "CFSHGh23sdh8sadbd8w82er")
                .addHeader("x-cors-" + appId.toLowerCase() + "-" +env, "1")
                .addHeader("Accept-Language", "en-CN")
                .addHeader("Operation-Type", operationType)
                .addHeader("Content-Length", "155")
                .addHeader("uuid", uuid)
                //.addHeader("did", "W/y4ghfdhFEWh3jgh8tryj")
                .addHeader("tenantId", tenantId)
                //.addHeader("ts", "1544009617477")
                .addHeader("User-Agent", "xiaomiMi 10")
                .addHeader("X-Apdid-Token", "mFHUabHM4wfBDXYSBRvdq38JCOnKl1m1lUgJBp4VsPR6kgcGdwEAAA==")
                .addHeader("Content-Type", contentType)
                .addHeader("Cookie", cookie)
                .addHeader("Connection", "keep-alive")
                .build();
        System.out.print("request is:"+request +"\n");
        return request;
    }
}
