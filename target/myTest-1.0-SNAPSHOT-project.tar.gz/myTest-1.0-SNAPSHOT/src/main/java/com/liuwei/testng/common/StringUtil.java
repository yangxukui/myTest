package com.liuwei.testng.common;

public class StringUtil {

    public static String subStingAfter(String str, String separator){
        if(str != null && str.length() != 0){
            if (separator == null){
                return "";
            }else {
                int pos = str.indexOf(separator);
                return pos == -1? "" : str.substring(pos + separator.length());
            }
        }else{
            return str;
        }
    }
}
