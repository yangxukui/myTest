package com.liuwei.testng.base;

import com.liuwei.testng.common.LogUtil;
import com.liuwei.testng.common.LoggerFactor;
import com.liuwei.testng.inter.Logger;
import org.testng.Reporter;

import java.text.SimpleDateFormat;
import java.util.Date;

public class LogUtils {

    public static void info(String msg){
//        LogUtil.info(LOGGER,msg);
//        Reporter.log(msg);

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        System.out.print("["+df.format(new Date())+"]"+msg+"\n");
    }
}
